package exampleForms;

import org.eclipse.swt.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.custom.ViewForm;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridLayout;
public class DummyEclipse extends org.eclipse.swt.widgets.Composite {
	TableItem tableItem2;
	TableItem tableItem1;
	ToolItem toolItem4;
	ToolItem toolItem3;
	ToolBar toolBar5;
	ToolBar toolBar4;
	ToolItem toolItem2;
	ToolItem toolItem1;
	ToolItem toolItem13;
	ToolItem separator3;
	ToolItem toolItem12;
	ToolItem toolItem11;
	ToolItem sep11;
	ToolItem toolItem10;
	MenuItem helpContMenuItem;
	Menu menu20;
	MenuItem helpMenuItem;
	MenuItem copyMenuItem;
	MenuItem pasteMenuItem;
	MenuItem cutMenuItem;
	MenuItem separator1;
	MenuItem redoMenuItem;
	MenuItem undoMenuItem;
	Menu menu15;
	MenuItem editMenuItem;
	MenuItem exitMenuItem;
	MenuItem saveMenuItem;
	MenuItem closeMenuItem;
	ToolItem separator2;
	ToolItem toolItem9;
	ToolBar toolBar3;
	MenuItem separator11;
	MenuItem packageItem;
	MenuItem menuItem5;
	MenuItem projectItem;
	Menu menu5;
	ToolItem toolItem8;
	ToolItem newToolItem;
	ToolItem toolItem6;
	ToolItem toolItem5;
	ToolBar toolBar2;
	ToolItem debugToolItem;
	ToolItem runToolItem;
	ToolBar toolBar1;
	CTabItem cTabItem10;
	CTabFolder cTabFolder6;
	Text text2;
	SashForm sashForm3;
	MenuItem newMenuItem;
	Menu menu3;
	Button button6;
	Button button5;
	ViewForm viewForm1;
	Tree tree7;
	Composite composite22;
	Composite composite21;
	TreeItem treeItem15;
	TreeItem treeItem14;
	TreeItem treeItem13;
	TableColumn tableColumn6;
	TableColumn tableColumn5;
	Table table2;
	CLabel cLabel9;
	Composite composite20;
	Composite composite19;
	CTabItem cTabItem7;
	CLabel cLabel7;
	Composite composite18;
	TreeItem treeItem9;
	TreeItem treeItem8;
	TreeItem treeItem7;
	Tree tree3;
	TableColumn tableColumn4;
	TableColumn tableColumn3;
	Table table1;
	CTabItem cTabItem8;
	TableColumn tableColumn2;
	TableColumn tableColumn1;
	TreeItem treeItem12;
	TreeItem treeItem11;
	TreeItem treeItem10;
	Table tree6;
	CLabel cLabel8;
	Composite composite24;
	Composite composite23;
	CTabItem cTabItem9;
	CTabFolder cTabFolder5;
	Text text1;
	ScrolledComposite scrolledComposite1;
	CTabItem cTabItem3;
	CTabFolder cTabFolder4;
	TreeItem treeItem6;
	TreeItem treeItem5;
	TreeItem treeItem4;
	Tree tree2;
	CLabel cLabel6;
	Composite composite17;
	Composite composite16;
	CTabItem cTabItem2;
	TreeItem treeItem3;
	TreeItem treeItem2;
	TreeItem treeItem1;
	Tree tree1;
	Composite composite7;
	CLabel cLabel3;
	Composite composite6;
	Composite composite5;
	Composite composite4;
	CTabItem cTabItem1;
	CTabFolder cTabFolder1;
	SashForm sashForm2;
	MenuItem fileMenuItem;
	Menu menu1;
	Button button4;
	Composite composite3;
	CTabItem cTabItem6;
	CTabFolder cTabFolder3;
	TreeItem treeItem21;
	TreeItem treeItem20;
	TreeItem treeItem19;
	Tree tree5;
	CLabel cLabel5;
	Composite composite15;
	Composite composite14;
	CTabItem cTabItem5;
	TreeItem treeItem18;
	TreeItem treeItem17;
	TreeItem treeItem16;
	Tree tree4;
	Composite composite12;
	CLabel cLabel4;
	Composite composite11;
	Composite composite10;
	Composite composite9;
	CTabItem cTabItem4;
	CTabFolder cTabFolder2;
	Label label2;
	Label label4;
	Label label3;
	Composite composite13;
	Composite composite8;
	CoolItem coolItem2;
	Button cLabel2;
	Composite composite2;
	CoolItem coolItem3;
	CoolItem coolItem1;
	CoolBar coolBar1;
	Composite composite1;
	Label label1;
	Button button3;
	Button button2;
	SashForm sashForm1;
	Button button1;
	public DummyEclipse(Composite parent, int style) {
		super(parent, style);
		initGUI();
	}
	/**
	* Auto-generated code - any changes you make will disappear!!!
	*/
	public void initGUI() {
		try {
			preInitGUI();
			label1 = new Label(this, 258);
			composite1 = new Composite(this, 0);
			coolBar1 = new CoolBar(composite1, 0);
			coolItem3 = new CoolItem(coolBar1, 4);
			toolBar2 = new ToolBar(coolBar1, 8388608);
			newToolItem = new ToolItem(toolBar2, 4);
			toolItem6 = new ToolItem(toolBar2, 0);
			toolItem5 = new ToolItem(toolBar2, 0);
			toolItem8 = new ToolItem(toolBar2, 0);
			separator3 = new ToolItem(toolBar2, 2);
			toolItem13 = new ToolItem(toolBar2, 0);
			coolItem1 = new CoolItem(coolBar1, 4);
			toolBar1 = new ToolBar(coolBar1, 8388608);
			debugToolItem = new ToolItem(toolBar1, 4);
			runToolItem = new ToolItem(toolBar1, 4);
			composite8 = new Composite(this, 0);
			composite13 = new Composite(composite8, 0);
			toolBar3 = new ToolBar(composite13, 8389120);
			toolItem9 = new ToolItem(toolBar3, 0);
			sep11 = new ToolItem(toolBar3, 2);
			toolItem10 = new ToolItem(toolBar3, 0);
			toolItem11 = new ToolItem(toolBar3, 2);
			toolItem12 = new ToolItem(toolBar3, 0);
			label2 = new Label(composite8, 2);
			composite6 = new Composite(composite8, 0);
			sashForm2 = new SashForm(composite6, 0);
			sashForm3 = new SashForm(sashForm2, 0);
			cTabFolder2 = new CTabFolder(sashForm3, 3080);
			cTabItem4 = new CTabItem(cTabFolder2, 0);
			composite7 = new Composite(cTabFolder2, 0);
			composite9 = new Composite(composite7, 0);
			cLabel4 = new CLabel(composite9, 0);
			toolBar5 = new ToolBar(composite9, 8388608);
			toolItem3 = new ToolItem(toolBar5, 0);
			toolItem4 = new ToolItem(toolBar5, 0);
			tree3 = new Tree(composite7, 0);
			treeItem7 = new TreeItem(tree3, 0);
			treeItem8 = new TreeItem(treeItem7, 0);
			treeItem9 = new TreeItem(treeItem7, 0);
			cTabItem5 = new CTabItem(cTabFolder2, 0);
			composite10 = new Composite(cTabFolder2, 0);
			composite11 = new Composite(composite10, 0);
			cLabel5 = new CLabel(composite11, 0);
			tree4 = new Tree(composite10, 0);
			treeItem10 = new TreeItem(tree4, 0);
			treeItem12 = new TreeItem(treeItem10, 0);
			treeItem11 = new TreeItem(treeItem10, 0);
			cTabFolder3 = new CTabFolder(sashForm3, 2056);
			cTabItem6 = new CTabItem(cTabFolder3, 0);
			text2 = new Text(cTabFolder3, 770);
			cTabItem7 = new CTabItem(cTabFolder3, 0);
			cTabFolder6 = new CTabFolder(sashForm2, 3080);
			cTabItem10 = new CTabItem(cTabFolder6, 0);
			composite12 = new Composite(cTabFolder6, 0);
			composite14 = new Composite(composite12, 0);
			cLabel7 = new CLabel(composite14, 0);
			toolBar4 = new ToolBar(composite14, 8388608);
			toolItem2 = new ToolItem(toolBar4, 0);
			toolItem1 = new ToolItem(toolBar4, 0);
			table1 = new Table(composite12, 32);
			tableColumn3 = new TableColumn(table1, 0);
			tableColumn4 = new TableColumn(table1, 0);
			tableItem1 = new TableItem(table1, 0);
			tableItem2 = new TableItem(table1, 0);
			this.setSize(new org.eclipse.swt.graphics.Point(489, 349));
			this.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 489, 349));
			label1.setText("label1");
			label1.setVisible(true);
			GridData label1LData = new GridData();
			label1LData.verticalAlignment = 2;
			label1LData.horizontalAlignment = 4;
			label1LData.widthHint = -1;
			label1LData.heightHint = -1;
			label1LData.horizontalIndent = 0;
			label1LData.horizontalSpan = 1;
			label1LData.verticalSpan = 1;
			label1LData.grabExcessHorizontalSpace = false;
			label1LData.grabExcessVerticalSpace = false;
			label1.setLayoutData(label1LData);
			composite1.setSize(new org.eclipse.swt.graphics.Point(488, 25));
			composite1.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 2, 488, 25));
			composite1.setVisible(true);
			GridData composite1LData = new GridData();
			composite1LData.verticalAlignment = 2;
			composite1LData.horizontalAlignment = 4;
			composite1LData.widthHint = 488;
			composite1LData.heightHint = 25;
			composite1LData.horizontalIndent = 0;
			composite1LData.horizontalSpan = 1;
			composite1LData.verticalSpan = 1;
			composite1LData.grabExcessHorizontalSpace = true;
			composite1LData.grabExcessVerticalSpace = false;
			composite1.setLayoutData(composite1LData);
			coolBar1.setSize(new org.eclipse.swt.graphics.Point(488, 25));
			coolBar1.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 488, 25));
			coolBar1.setVisible(true);
			coolItem3.setSize(new org.eclipse.swt.graphics.Point(149, 23));
			coolItem3.setMinimumSize(new org.eclipse.swt.graphics.Point(80, 0));
			coolItem3.setPreferredSize(
				new org.eclipse.swt.graphics.Point(149, 23));
			coolItem3.setText("coolItem3");
			toolBar2.setSize(new org.eclipse.swt.graphics.Point(114, 18));
			toolBar2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(9, 0, 114, 18));
			toolBar2.setVisible(true);
			coolItem3.setControl(toolBar2);
			final org.eclipse.swt.graphics.Image newToolItemimage =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/new_wiz.gif"));
			newToolItem.setImage(newToolItemimage);
			newToolItem.setText("");
			newToolItem.addSelectionListener(new SelectionAdapter() {
				public void widgetSelected(SelectionEvent evt) {
					newToolItemWidgetSelected(evt);
				}
			});
			final org.eclipse.swt.graphics.Image toolItem6image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/save_edit.gif"));
			toolItem6.setImage(toolItem6image);
			toolItem6.setText("");
			final org.eclipse.swt.graphics.Image toolItem5image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/saveas_edit.gif"));
			toolItem5.setImage(toolItem5image);
			toolItem5.setText("");
			toolItem8.setEnabled(true);
			final org.eclipse.swt.graphics.Image toolItem8image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/print_edit.gif"));
			toolItem8.setImage(toolItem8image);
			separator3.setText("");
			final org.eclipse.swt.graphics.Image toolItem13image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/build_exec.gif"));
			toolItem13.setImage(toolItem13image);
			toolItem13.setText("");
			toolBar2.setLayout(null);
			toolBar2.layout();
			coolItem1.setSize(new org.eclipse.swt.graphics.Point(342, 23));
			coolItem1.setPreferredSize(
				new org.eclipse.swt.graphics.Point(342, 23));
			coolItem1.setText("");
			toolBar1.setSize(new org.eclipse.swt.graphics.Point(325, 21));
			toolBar1.setBounds(
				new org.eclipse.swt.graphics.Rectangle(10, 2, 325, 21));
			toolBar1.setVisible(true);
			coolItem1.setControl(toolBar1);
			final org.eclipse.swt.graphics.Image debugToolItemimage =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/debug_exec.gif"));
			debugToolItem.setImage(debugToolItemimage);
			debugToolItem.setText("");
			debugToolItem.addSelectionListener(new SelectionAdapter() {
				public void widgetSelected(SelectionEvent evt) {
					debugToolItemWidgetSelected(evt);
				}
			});
			final org.eclipse.swt.graphics.Image runToolItemimage =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/run_exec.gif"));
			runToolItem.setImage(runToolItemimage);
			runToolItem.setText("");
			runToolItem.addSelectionListener(new SelectionAdapter() {
				public void widgetSelected(SelectionEvent evt) {
					runToolItemWidgetSelected(evt);
				}
			});
			toolBar1.setLayout(null);
			toolBar1.layout();
			coolBar1.setLayout(null);
			coolBar1.layout();
			FillLayout composite1Layout = new FillLayout(256);
			composite1.setLayout(composite1Layout);
			composite1Layout.type = 256;
			composite1.layout();
			composite8.setSize(new org.eclipse.swt.graphics.Point(-305, -303));
			composite8.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 33, 475, 289));
			composite8.setVisible(true);
			GridData composite8LData = new GridData();
			composite8LData.verticalAlignment = 4;
			composite8LData.horizontalAlignment = 4;
			composite8LData.widthHint = -305;
			composite8LData.heightHint = -303;
			composite8LData.horizontalIndent = 0;
			composite8LData.horizontalSpan = 1;
			composite8LData.verticalSpan = 1;
			composite8LData.grabExcessHorizontalSpace = false;
			composite8LData.grabExcessVerticalSpace = true;
			composite8.setLayoutData(composite8LData);
			composite13.setSize(new org.eclipse.swt.graphics.Point(25, 301));
			composite13.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 25, 301));
			composite13.setVisible(true);
			GridData composite13LData = new GridData();
			composite13LData.verticalAlignment = 4;
			composite13LData.horizontalAlignment = 1;
			composite13LData.widthHint = 25;
			composite13LData.heightHint = 301;
			composite13LData.horizontalIndent = 0;
			composite13LData.horizontalSpan = 1;
			composite13LData.verticalSpan = 1;
			composite13LData.grabExcessHorizontalSpace = false;
			composite13LData.grabExcessVerticalSpace = true;
			composite13.setLayoutData(composite13LData);
			toolBar3.setSize(new org.eclipse.swt.graphics.Point(23, 97));
			toolBar3.setBounds(
				new org.eclipse.swt.graphics.Rectangle(2, 2, 23, 97));
			toolBar3.setVisible(true);
			GridData toolBar3LData = new GridData();
			toolBar3LData.verticalAlignment = 2;
			toolBar3LData.horizontalAlignment = 1;
			toolBar3LData.widthHint = 23;
			toolBar3LData.heightHint = 97;
			toolBar3LData.horizontalIndent = 0;
			toolBar3LData.horizontalSpan = 1;
			toolBar3LData.verticalSpan = 1;
			toolBar3LData.grabExcessHorizontalSpace = false;
			toolBar3LData.grabExcessVerticalSpace = false;
			toolBar3.setLayoutData(toolBar3LData);
			final org.eclipse.swt.graphics.Image toolItem9image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/new_persp.gif"));
			toolItem9.setImage(toolItem9image);
			toolItem9.setText("");
			sep11.setText("");
			final org.eclipse.swt.graphics.Image toolItem10image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/resource_persp.gif"));
			toolItem10.setImage(toolItem10image);
			toolItem10.setText("");
			toolItem11.setText("");
			final org.eclipse.swt.graphics.Image toolItem12image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/java/jperspective.gif"));
			toolItem12.setImage(toolItem12image);
			toolItem12.setText("");
			toolBar3.setLayout(null);
			toolBar3.layout();
			GridLayout composite13Layout = new GridLayout(1, true);
			composite13.setLayout(composite13Layout);
			composite13Layout.marginWidth = 2;
			composite13Layout.marginHeight = 2;
			composite13Layout.numColumns = 1;
			composite13Layout.makeColumnsEqualWidth = true;
			composite13Layout.horizontalSpacing = 0;
			composite13Layout.verticalSpacing = 2;
			composite13.layout();
			label2.setText("label2");
			label2.setSize(new org.eclipse.swt.graphics.Point(2, -1));
			label2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(27, 0, 2, 302));
			label2.setVisible(true);
			GridData label2LData = new GridData();
			label2LData.verticalAlignment = 4;
			label2LData.horizontalAlignment = 1;
			label2LData.widthHint = 2;
			label2LData.heightHint = -1;
			label2LData.horizontalIndent = 0;
			label2LData.horizontalSpan = 1;
			label2LData.verticalSpan = 1;
			label2LData.grabExcessHorizontalSpace = false;
			label2LData.grabExcessVerticalSpace = true;
			label2.setLayoutData(label2LData);
			composite6.setVisible(true);
			GridData composite6LData = new GridData();
			composite6LData.verticalAlignment = 4;
			composite6LData.horizontalAlignment = 4;
			composite6LData.widthHint = -1;
			composite6LData.heightHint = -1;
			composite6LData.horizontalIndent = 0;
			composite6LData.horizontalSpan = 1;
			composite6LData.verticalSpan = 1;
			composite6LData.grabExcessHorizontalSpace = true;
			composite6LData.grabExcessVerticalSpace = true;
			composite6.setLayoutData(composite6LData);
			sashForm2.setOrientation(512);
			sashForm2.setSize(new org.eclipse.swt.graphics.Point(270, 175));
			sashForm2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(37, 2, 442, 284));
			sashForm2.setVisible(true);
			GridData sashForm2LData = new GridData();
			sashForm2LData.verticalAlignment = 4;
			sashForm2LData.horizontalAlignment = 4;
			sashForm2LData.widthHint = 270;
			sashForm2LData.heightHint = 175;
			sashForm2LData.horizontalIndent = 0;
			sashForm2LData.horizontalSpan = 1;
			sashForm2LData.verticalSpan = 1;
			sashForm2LData.grabExcessHorizontalSpace = true;
			sashForm2LData.grabExcessVerticalSpace = true;
			sashForm2.setLayoutData(sashForm2LData);
			sashForm3.setSize(new org.eclipse.swt.graphics.Point(442, 284));
			sashForm3.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 442, 284));
			sashForm3.setVisible(true);
			cTabFolder2.setSize(new org.eclipse.swt.graphics.Point(214, 116));
			cTabFolder2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 218, 140));
			cTabFolder2.setVisible(true);
			cTabItem4.setText("Package Explorer");
			composite7.setVisible(true);
			cTabItem4.setControl(composite7);
			composite9.setSize(new org.eclipse.swt.graphics.Point(163, 24));
			composite9.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 163, 24));
			composite9.setVisible(true);
			GridData composite9LData = new GridData();
			composite9LData.verticalAlignment = 2;
			composite9LData.horizontalAlignment = 4;
			composite9LData.widthHint = 163;
			composite9LData.heightHint = 24;
			composite9LData.horizontalIndent = 0;
			composite9LData.horizontalSpan = 1;
			composite9LData.verticalSpan = 1;
			composite9LData.grabExcessHorizontalSpace = true;
			composite9LData.grabExcessVerticalSpace = false;
			composite9.setLayoutData(composite9LData);
			final org.eclipse.swt.graphics.Image cLabel4image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/java/package.gif"));
			cLabel4image.setBackground(cLabel4.getBackground());
			cLabel4.setImage(cLabel4image);
			cLabel4.setText("Package Explorer");
			cLabel4.setSize(new org.eclipse.swt.graphics.Point(119, 20));
			cLabel4.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 1, 173, 20));
			cLabel4.setVisible(true);
			GridData cLabel4LData = new GridData();
			cLabel4LData.verticalAlignment = 2;
			cLabel4LData.horizontalAlignment = 4;
			cLabel4LData.widthHint = 119;
			cLabel4LData.heightHint = 20;
			cLabel4LData.horizontalIndent = 0;
			cLabel4LData.horizontalSpan = 1;
			cLabel4LData.verticalSpan = 1;
			cLabel4LData.grabExcessHorizontalSpace = true;
			cLabel4LData.grabExcessVerticalSpace = false;
			cLabel4.setLayoutData(cLabel4LData);
			cLabel4.setLayout(null);
			cLabel4.layout();
			toolBar5.setVisible(true);
			GridData toolBar5LData = new GridData();
			toolBar5LData.verticalAlignment = 2;
			toolBar5LData.horizontalAlignment = 1;
			toolBar5LData.widthHint = -1;
			toolBar5LData.heightHint = -1;
			toolBar5LData.horizontalIndent = 0;
			toolBar5LData.horizontalSpan = 1;
			toolBar5LData.verticalSpan = 1;
			toolBar5LData.grabExcessHorizontalSpace = false;
			toolBar5LData.grabExcessVerticalSpace = false;
			toolBar5.setLayoutData(toolBar5LData);
			final org.eclipse.swt.graphics.Image toolItem3image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/view_menu.gif"));
			toolItem3.setImage(toolItem3image);
			toolItem3.setText("");
			final org.eclipse.swt.graphics.Image toolItem4image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/close_view.gif"));
			toolItem4.setImage(toolItem4image);
			toolItem4.setText("");
			toolBar5.setLayout(null);
			toolBar5.layout();
			GridLayout composite9Layout = new GridLayout(2, true);
			composite9.setLayout(composite9Layout);
			composite9Layout.marginWidth = 0;
			composite9Layout.marginHeight = 0;
			composite9Layout.numColumns = 2;
			composite9Layout.makeColumnsEqualWidth = false;
			composite9Layout.horizontalSpacing = 0;
			composite9Layout.verticalSpacing = 0;
			composite9.layout();
			tree3.setSize(new org.eclipse.swt.graphics.Point(197, 74));
			tree3.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 24, 213, 90));
			tree3.setVisible(true);
			GridData tree3LData = new GridData();
			tree3LData.verticalAlignment = 4;
			tree3LData.horizontalAlignment = 4;
			tree3LData.widthHint = 197;
			tree3LData.heightHint = 74;
			tree3LData.horizontalIndent = 0;
			tree3LData.horizontalSpan = 1;
			tree3LData.verticalSpan = 1;
			tree3LData.grabExcessHorizontalSpace = false;
			tree3LData.grabExcessVerticalSpace = true;
			tree3.setLayoutData(tree3LData);
			final org.eclipse.swt.graphics.Image treeItem7image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/java/package_obj.gif"));
			treeItem7.setImage(treeItem7image);
			treeItem7.setText("testPackage");
			treeItem7.setExpanded(true);
			final org.eclipse.swt.graphics.Image treeItem8image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/java/jcu_obj.gif"));
			treeItem8.setImage(treeItem8image);
			treeItem8.setText("Class1");
			final org.eclipse.swt.graphics.Image treeItem9image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/java/jcu_obj.gif"));
			treeItem9.setImage(treeItem9image);
			treeItem9.setText("Class2");
			tree3.setLayout(null);
			tree3.layout();
			GridLayout composite7Layout = new GridLayout(1, true);
			composite7.setLayout(composite7Layout);
			composite7Layout.marginWidth = 0;
			composite7Layout.marginHeight = 0;
			composite7Layout.numColumns = 1;
			composite7Layout.makeColumnsEqualWidth = true;
			composite7Layout.horizontalSpacing = 0;
			composite7Layout.verticalSpacing = 0;
			composite7.layout();
			cTabItem5.setText("Hierarchy");
			composite10.setVisible(true);
			cTabItem5.setControl(composite10);
			composite11.setSize(new org.eclipse.swt.graphics.Point(213, 24));
			composite11.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 213, 24));
			composite11.setVisible(true);
			GridData composite11LData = new GridData();
			composite11LData.verticalAlignment = 2;
			composite11LData.horizontalAlignment = 4;
			composite11LData.widthHint = 213;
			composite11LData.heightHint = 24;
			composite11LData.horizontalIndent = 0;
			composite11LData.horizontalSpan = 1;
			composite11LData.verticalSpan = 1;
			composite11LData.grabExcessHorizontalSpace = true;
			composite11LData.grabExcessVerticalSpace = false;
			composite11.setLayoutData(composite11LData);
			final org.eclipse.swt.graphics.Image cLabel5image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/sample.gif"));
			cLabel5image.setBackground(cLabel5.getBackground());
			cLabel5.setImage(cLabel5image);
			cLabel5.setText("Hierarchy");
			cLabel5.setSize(new org.eclipse.swt.graphics.Point(85, 17));
			cLabel5.setBounds(
				new org.eclipse.swt.graphics.Rectangle(3, 3, 85, 17));
			cLabel5.setVisible(true);
			cLabel5.setLayout(null);
			cLabel5.layout();
			composite11.setLayout(null);
			composite11.layout();
			tree4.setSize(new org.eclipse.swt.graphics.Point(-126, -34));
			tree4.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 24, 209, 236));
			tree4.setVisible(true);
			GridData tree4LData = new GridData();
			tree4LData.verticalAlignment = 4;
			tree4LData.horizontalAlignment = 4;
			tree4LData.widthHint = -126;
			tree4LData.heightHint = -34;
			tree4LData.horizontalIndent = 0;
			tree4LData.horizontalSpan = 1;
			tree4LData.verticalSpan = 1;
			tree4LData.grabExcessHorizontalSpace = true;
			tree4LData.grabExcessVerticalSpace = true;
			tree4.setLayoutData(tree4LData);
			treeItem10.setText("Composite");
			treeItem10.setExpanded(true);
			treeItem12.setText("Canvas");
			treeItem11.setText("SashForm");
			tree4.setLayout(null);
			tree4.layout();
			GridLayout composite10Layout = new GridLayout(1, true);
			composite10.setLayout(composite10Layout);
			composite10Layout.marginWidth = 0;
			composite10Layout.marginHeight = 0;
			composite10Layout.numColumns = 1;
			composite10Layout.makeColumnsEqualWidth = true;
			composite10Layout.horizontalSpacing = 0;
			composite10Layout.verticalSpacing = 0;
			composite10.layout();
			cTabFolder2.setLayout(null);
			cTabFolder2.layout();
			cTabFolder2.setSelection(0);
			cTabFolder3.setSize(new org.eclipse.swt.graphics.Point(218, 111));
			cTabFolder3.setBounds(
				new org.eclipse.swt.graphics.Rectangle(220, 0, 222, 138));
			cTabFolder3.setVisible(true);
			final org.eclipse.swt.graphics.Image cTabItem6image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/java/jcu_obj.gif"));
			cTabItem6.setImage(cTabItem6image);
			cTabItem6.setText("FakeJava.java");
			text2.setText(
				"package fake;\n\npublic class FakeJava {\n\n\tpublic FakeJava() {\n\t}\n\n}");
			text2.setVisible(true);
			cTabItem6.setControl(text2);
			final org.eclipse.swt.graphics.Image cTabItem7image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/form.gif"));
			cTabItem7.setImage(cTabItem7image);
			cTabItem7.setText("FakeJava.form");
			cTabFolder3.setLayout(null);
			cTabFolder3.layout();
			cTabFolder3.setSelection(0);
			sashForm3.setLayout(null);
			sashForm3.layout();
			cTabFolder6.setSize(new org.eclipse.swt.graphics.Point(213, 114));
			cTabFolder6.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 217, 138));
			cTabFolder6.setVisible(true);
			cTabItem10.setText("Properties");
			composite12.setVisible(true);
			cTabItem10.setControl(composite12);
			composite14.setSize(new org.eclipse.swt.graphics.Point(213, 24));
			composite14.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 451, 24));
			composite14.setVisible(true);
			GridData composite14LData = new GridData();
			composite14LData.verticalAlignment = 2;
			composite14LData.horizontalAlignment = 4;
			composite14LData.widthHint = 213;
			composite14LData.heightHint = 24;
			composite14LData.horizontalIndent = 0;
			composite14LData.horizontalSpan = 1;
			composite14LData.verticalSpan = 1;
			composite14LData.grabExcessHorizontalSpace = true;
			composite14LData.grabExcessVerticalSpace = false;
			composite14.setLayoutData(composite14LData);
			final org.eclipse.swt.graphics.Image cLabel7image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/prop_ps.gif"));
			cLabel7image.setBackground(cLabel7.getBackground());
			cLabel7.setImage(cLabel7image);
			cLabel7.setText("Properties");
			cLabel7.setVisible(true);
			final Color cLabel7foreground =
				new Color(getDisplay(), 255, 255, 255);
			cLabel7.setForeground(cLabel7foreground);
			GridData cLabel7LData = new GridData();
			cLabel7LData.verticalAlignment = 4;
			cLabel7LData.horizontalAlignment = 4;
			cLabel7LData.widthHint = -78;
			cLabel7LData.heightHint = -24;
			cLabel7LData.horizontalIndent = 0;
			cLabel7LData.horizontalSpan = 1;
			cLabel7LData.verticalSpan = 1;
			cLabel7LData.grabExcessHorizontalSpace = true;
			cLabel7LData.grabExcessVerticalSpace = false;
			cLabel7.setLayoutData(cLabel7LData);
			cLabel7.setLayout(null);
			cLabel7.layout();
			toolBar4.setVisible(true);
			GridData toolBar4LData = new GridData();
			toolBar4LData.verticalAlignment = 2;
			toolBar4LData.horizontalAlignment = 1;
			toolBar4LData.widthHint = -1;
			toolBar4LData.heightHint = -1;
			toolBar4LData.horizontalIndent = 0;
			toolBar4LData.horizontalSpan = 1;
			toolBar4LData.verticalSpan = 1;
			toolBar4LData.grabExcessHorizontalSpace = false;
			toolBar4LData.grabExcessVerticalSpace = false;
			toolBar4.setLayoutData(toolBar4LData);
			final org.eclipse.swt.graphics.Image toolItem2image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/view_menu.gif"));
			toolItem2.setImage(toolItem2image);
			toolItem2.setText("");
			final org.eclipse.swt.graphics.Image toolItem1image =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/close_view.gif"));
			toolItem1.setImage(toolItem1image);
			toolItem1.setText("");
			toolBar4.setLayout(null);
			toolBar4.layout();
			GridLayout composite14Layout = new GridLayout(2, true);
			composite14.setLayout(composite14Layout);
			composite14Layout.marginWidth = 0;
			composite14Layout.marginHeight = 0;
			composite14Layout.numColumns = 2;
			composite14Layout.makeColumnsEqualWidth = false;
			composite14Layout.horizontalSpacing = 0;
			composite14Layout.verticalSpacing = 0;
			composite14.layout();
			table1.setHeaderVisible(true);
			table1.setLinesVisible(true);
			table1.setSize(new org.eclipse.swt.graphics.Point(422, 79));
			table1.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 24, 438, 95));
			table1.setVisible(true);
			GridData table1LData = new GridData();
			table1LData.verticalAlignment = 4;
			table1LData.horizontalAlignment = 4;
			table1LData.widthHint = 422;
			table1LData.heightHint = 79;
			table1LData.horizontalIndent = 0;
			table1LData.horizontalSpan = 1;
			table1LData.verticalSpan = 1;
			table1LData.grabExcessHorizontalSpace = false;
			table1LData.grabExcessVerticalSpace = true;
			table1.setLayoutData(table1LData);
			tableColumn3.setText("Property");
			tableColumn3.setWidth(100);
			tableColumn4.setText("Value");
			tableColumn4.setWidth(100);
			tableItem1.setText("tableItem1");
			tableItem1.setChecked(true);
			tableItem2.setText("tableItem2");
			tableItem2.setGrayed(true);
			table1.setLayout(null);
			table1.layout();
			GridLayout composite12Layout = new GridLayout(1, true);
			composite12.setLayout(composite12Layout);
			composite12Layout.marginWidth = 0;
			composite12Layout.marginHeight = 0;
			composite12Layout.numColumns = 1;
			composite12Layout.makeColumnsEqualWidth = true;
			composite12Layout.horizontalSpacing = 0;
			composite12Layout.verticalSpacing = 0;
			composite12.layout();
			cTabFolder6.setLayout(null);
			cTabFolder6.layout();
			cTabFolder6.setSelection(0);
			sashForm2.setLayout(null);
			sashForm2.layout();
			GridLayout composite6Layout = new GridLayout(1, true);
			composite6.setLayout(composite6Layout);
			composite6Layout.marginWidth = 1;
			composite6Layout.marginHeight = 3;
			composite6Layout.numColumns = 1;
			composite6Layout.makeColumnsEqualWidth = true;
			composite6Layout.horizontalSpacing = 2;
			composite6Layout.verticalSpacing = 2;
			composite6.layout();
			GridLayout composite8Layout = new GridLayout(3, true);
			composite8.setLayout(composite8Layout);
			composite8Layout.marginWidth = 0;
			composite8Layout.marginHeight = 0;
			composite8Layout.numColumns = 3;
			composite8Layout.makeColumnsEqualWidth = false;
			composite8Layout.horizontalSpacing = 2;
			composite8Layout.verticalSpacing = 0;
			composite8.layout();
			GridLayout thisLayout = new GridLayout(1, true);
			this.setLayout(thisLayout);
			thisLayout.marginWidth = 0;
			thisLayout.marginHeight = 0;
			thisLayout.numColumns = 1;
			thisLayout.makeColumnsEqualWidth = true;
			thisLayout.horizontalSpacing = 0;
			thisLayout.verticalSpacing = 0;
			this.layout();
			menu1 = new Menu(getShell(), 2);
			fileMenuItem = new MenuItem(menu1, 64);
			menu3 = new Menu(fileMenuItem);
			newMenuItem = new MenuItem(menu3, 64);
			menu5 = new Menu(newMenuItem);
			projectItem = new MenuItem(menu5, 8);
			menuItem5 = new MenuItem(menu5, 2);
			packageItem = new MenuItem(menu5, 8);
			separator11 = new MenuItem(menu3, 2);
			closeMenuItem = new MenuItem(menu3, 8);
			saveMenuItem = new MenuItem(menu3, 8);
			exitMenuItem = new MenuItem(menu3, 8);
			editMenuItem = new MenuItem(menu1, 64);
			menu15 = new Menu(editMenuItem);
			undoMenuItem = new MenuItem(menu15, 8);
			redoMenuItem = new MenuItem(menu15, 8);
			separator1 = new MenuItem(menu15, 2);
			cutMenuItem = new MenuItem(menu15, 8);
			pasteMenuItem = new MenuItem(menu15, 8);
			copyMenuItem = new MenuItem(menu15, 8);
			helpMenuItem = new MenuItem(menu1, 64);
			menu20 = new Menu(helpMenuItem);
			helpContMenuItem = new MenuItem(menu20, 8);
			getShell().setMenuBar(menu1);
			menu1.setVisible(true);
			fileMenuItem.setText("&File");
			fileMenuItem.setMenu(menu3);
			menu3.setVisible(true);
			newMenuItem.setText("&New");
			newMenuItem.setMenu(menu5);
			menu5.setVisible(true);
			projectItem.setText("Project");
			menuItem5.setText("");
			packageItem.setText("Package");
			separator11.setText("");
			closeMenuItem.setText("&Close");
			final org.eclipse.swt.graphics.Image saveMenuItemimage =
				new org.eclipse.swt.graphics.Image(
					Display.getDefault(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/save.gif"));
			saveMenuItem.setImage(saveMenuItemimage);
			saveMenuItem.setText("&Save");
			exitMenuItem.setText("&Exit");
			editMenuItem.setText("&Edit");
			editMenuItem.setMenu(menu15);
			menu15.setVisible(true);
			undoMenuItem.setText("Undo");
			redoMenuItem.setText("Redo");
			separator1.setText("menuItem27");
			cutMenuItem.setText("Cut");
			pasteMenuItem.setText("Paste");
			copyMenuItem.setText("Copy");
			helpMenuItem.setEnabled(true);
			helpMenuItem.setText("&Help");
			helpMenuItem.setMenu(menu20);
			menu20.setVisible(true);
			helpContMenuItem.setText("Help &Contents");
			addDisposeListener(new DisposeListener() {
				public void widgetDisposed(DisposeEvent e) {
					newToolItemimage.dispose();
					toolItem6image.dispose();
					toolItem5image.dispose();
					toolItem8image.dispose();
					toolItem13image.dispose();
					debugToolItemimage.dispose();
					runToolItemimage.dispose();
					toolItem9image.dispose();
					toolItem10image.dispose();
					toolItem12image.dispose();
					cLabel4image.dispose();
					toolItem3image.dispose();
					toolItem4image.dispose();
					treeItem7image.dispose();
					treeItem8image.dispose();
					treeItem9image.dispose();
					cLabel5image.dispose();
					cTabItem6image.dispose();
					cTabItem7image.dispose();
					cLabel7image.dispose();
					cLabel7foreground.dispose();
					toolItem2image.dispose();
					toolItem1image.dispose();
					saveMenuItemimage.dispose();
				}

			});
			postInitGUI();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/** Auto-generated main method */
	public static void main(String[] args) {
		showGUI();
	}

	/**
	* Auto-generated code - any changes you make will disappear!!!
	* This static method creates a new instance of this class and shows
	* it inside a Shell.
	*/
	public static void showGUI() {
		try {
			Display display = new Display();
			Shell shell = new Shell(display);
			DummyEclipse inst = new DummyEclipse(shell, SWT.NULL);
			shell.setLayout(new org.eclipse.swt.layout.FillLayout());
			Point size = inst.getSize();
			Rectangle shellBounds = shell.computeTrim(0, 0, size.x, size.y);
			if (shell.getMenuBar() != null)
				shellBounds.height -= 22;
			shell.setSize(shellBounds.width, shellBounds.height);
			shell.open();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
								* Add your pre-init code in here
								*/
	public void preInitGUI() {}

	/**
	* Add your post-init code in here
	*/
	public void postInitGUI() {
		Display display = cLabel7.getDisplay();
		cLabel7.setBackground(
			new Color[] {
				display.getSystemColor(SWT.COLOR_DARK_BLUE),
				display.getSystemColor(SWT.COLOR_BLUE),
				null },
			new int[] { 50, 100 });

	}

	/** Auto-generated event handler method */
	public void newToolItemWidgetSelected(SelectionEvent evt) {
		if (evt.detail == SWT.ARROW) {
			Menu menu = new Menu(getShell(), SWT.POP_UP);
			MenuItem mi = new MenuItem(menu, SWT.PUSH);
			mi.setText("New...");
			Rectangle b = newToolItem.getBounds();
			Point pt = new Point(b.x, b.y + b.height);
			pt = newToolItem.getParent().toDisplay(pt);
			menu.setLocation(pt.x, pt.y);
			menu.setVisible(true);
		}
	}

	/** Auto-generated event handler method */
	public void runToolItemWidgetSelected(SelectionEvent evt) {
		if (evt.detail == SWT.ARROW) {
			Menu menu = new Menu(getShell(), SWT.POP_UP);
			MenuItem mi = new MenuItem(menu, SWT.PUSH);
			mi.setText("Run...");
			Rectangle b = runToolItem.getBounds();
			Point pt = new Point(b.x, b.y + b.height);
			pt = runToolItem.getParent().toDisplay(pt);
			menu.setLocation(pt.x, pt.y);
			menu.setVisible(true);
		}
	}

	/** Auto-generated event handler method */
	public void debugToolItemWidgetSelected(SelectionEvent evt) {
		if (evt.detail == SWT.ARROW) {
			Menu menu = new Menu(getShell(), SWT.POP_UP);
			MenuItem mi = new MenuItem(menu, SWT.PUSH);
			mi.setText("Debug...");
			Rectangle b = debugToolItem.getBounds();
			Point pt = new Point(b.x, b.y + b.height);
			pt = debugToolItem.getParent().toDisplay(pt);
			menu.setLocation(pt.x, pt.y);
			menu.setVisible(true);
		}
	}
}
