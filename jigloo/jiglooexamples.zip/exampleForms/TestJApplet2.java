package exampleForms;

import javax.swing.*;
import exampleForms.TestJInternalFrame;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridBagConstraints;
import javax.swing.ImageIcon;
import java.awt.GridBagLayout;
import java.awt.FlowLayout;
import java.awt.CardLayout;
public class TestJApplet2 extends javax.swing.JApplet {
	JMenuItem jMenuItem2;
	JMenu jMenu3;
	JSeparator jSeparator1;
	JMenuItem jMenuItem1;
	JMenu jMenu2;
	JMenu jMenu1;
	JMenuBar jMenuBar1;
	JRadioButton jRadioButton1;
	JButton jButton6;
	JPanel jPanel5;
	JButton jButton7;
	JButton jButton5;
	JPanel jPanel4;
	JPanel jPanel3;
	TestJInternalFrame jInternalFrame2;
	JPanel jPanel6;
	JInternalFrame jInternalFrame1;
	JDesktopPane jDesktopPane1;
	JButton jButton4;
	JButton jButton3;
	JButton jButton2;
	JComboBox jComboBox1;
	JPanel jPanel2;
	JButton jButton1;
	JTabbedPane jTabbedPane1;
	JPanel jPanel1;
	public TestJApplet2() {
		initGUI();
	}

	/** Auto-generated event handler method */
	public void jButton1ActionPerformed(ActionEvent evt) {
		//TODO add your handler code here
	}

	/** Auto-generated event handler method */
	public void jButton5ActionPerformed(ActionEvent evt) {
		//TODO add your handler code here
	}

	/** Auto-generated event handler method */
	public void jButton7ActionPerformed(ActionEvent evt) {
		//TODO add your handler code here
	}
	/**
	* Auto-generated code - any changes you make will disappear!!!
	*/
	public void initGUI() {
		try {
			preInitGUI();
			jPanel1 = new JPanel();
			jTabbedPane1 = new JTabbedPane();
			jButton1 = new JButton();
			jPanel2 = new JPanel();
			jComboBox1 = new JComboBox();
			jButton2 = new JButton();
			jButton3 = new JButton();
			jButton4 = new JButton();
			jDesktopPane1 = new JDesktopPane();
			jInternalFrame1 = new JInternalFrame();
			jPanel6 = new JPanel();
			jInternalFrame2 = new TestJInternalFrame();
			jPanel3 = new JPanel();
			jPanel4 = new JPanel();
			jButton5 = new JButton();
			jButton7 = new JButton();
			jPanel5 = new JPanel();
			jButton6 = new JButton();
			jRadioButton1 = new JRadioButton();
			BorderLayout thisLayout = new BorderLayout();
			this.getContentPane().setLayout(thisLayout);
			thisLayout.setHgap(0);
			thisLayout.setVgap(0);
			this.getContentPane().setSize(new java.awt.Dimension(356, 180));
			BorderLayout jPanel1Layout = new BorderLayout();
			jPanel1.setLayout(jPanel1Layout);
			jPanel1Layout.setHgap(0);
			jPanel1Layout.setVgap(0);
			jPanel1.setPreferredSize(new java.awt.Dimension(284, 162));
			jPanel1.setBounds(new java.awt.Rectangle(0, 0, 356, 180));
			this.getContentPane().add(jPanel1, BorderLayout.CENTER);
			jTabbedPane1.setPreferredSize(new java.awt.Dimension(256, 164));
			jTabbedPane1.setBounds(new java.awt.Rectangle(0, 0, 356, 180));
			jPanel1.add(jTabbedPane1, BorderLayout.CENTER);
			jButton1.setText("jButton1");
			jButton1.setIcon(new ImageIcon("icons/package_obj.gif"));
			jTabbedPane1.add(jButton1);
			jTabbedPane1.setTitleAt(0, "test tab");
			jButton1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					jButton1ActionPerformed(evt);
				}
			});
			GridBagLayout jPanel2Layout = new GridBagLayout();
			jPanel2.setLayout(jPanel2Layout);
			jPanel2Layout.columnWidths = null;
			jPanel2Layout.rowHeights = null;
			jPanel2Layout.columnWeights = null;
			jPanel2Layout.rowWeights = null;
			jTabbedPane1.add(jPanel2);
			jTabbedPane1.setTitleAt(1, "tab2");
			jComboBox1.setPreferredSize(new java.awt.Dimension(83, 35));
			jComboBox1.setBounds(new java.awt.Rectangle(53, 45, 83, 35));
			jPanel2.add(jComboBox1);
			jButton2.setText("jButton2");
			jPanel2.add(
				jButton2,
				new GridBagConstraints(
					-1,
					-1,
					-1,
					1,
					0.0,
					0.0,
					10,
					0,
					new Insets(0, 0, 0, 0),
					0,
					0));
			jButton3.setText("jButton2");
			jPanel2.add(
				jButton3,
				new GridBagConstraints(
					-1,
					-1,
					0,
					1,
					0.0,
					0.0,
					10,
					0,
					new Insets(0, 0, 0, 0),
					0,
					0));
			jButton4.setText("jButton2");
			jPanel2.add(
				jButton4,
				new GridBagConstraints(
					-1,
					-1,
					-1,
					1,
					0.0,
					0.0,
					10,
					0,
					new Insets(0, 0, 0, 0),
					0,
					0));
			jDesktopPane1.setLayout(null);
			jTabbedPane1.add(jDesktopPane1);
			jTabbedPane1.setTitleAt(2, "tab3");
			BorderLayout jInternalFrame1Layout = new BorderLayout();
			jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
			jInternalFrame1Layout.setHgap(0);
			jInternalFrame1Layout.setVgap(0);
			jInternalFrame1.setClosable(true);
			jInternalFrame1.setMaximizable(true);
			jInternalFrame1.setFrameIcon(new ImageIcon("icons/form.gif"));
			jInternalFrame1.setVisible(true);
			jInternalFrame1.setPreferredSize(new java.awt.Dimension(121, 85));
			jInternalFrame1.setLocation(new java.awt.Point(220, 20));
			jInternalFrame1.setBounds(new java.awt.Rectangle(186, 36, 121, 85));
			jDesktopPane1.add(jInternalFrame1);
			FlowLayout jPanel6Layout = new FlowLayout();
			jPanel6.setLayout(jPanel6Layout);
			jPanel6Layout.setAlignment(0);
			jPanel6Layout.setHgap(0);
			jPanel6Layout.setVgap(0);
			jPanel6.setVisible(true);
			jInternalFrame1.getContentPane().add(jPanel6);
			jInternalFrame2.getContentPane().setLayout(null);
			jInternalFrame2.setVisible(true);
			jInternalFrame2.setPreferredSize(new java.awt.Dimension(161, 114));
			jInternalFrame2.setBounds(new java.awt.Rectangle(8, 33, 161, 114));
			jDesktopPane1.add(jInternalFrame2);
			BorderLayout jPanel3Layout = new BorderLayout();
			jPanel3.setLayout(jPanel3Layout);
			jPanel3Layout.setHgap(0);
			jPanel3Layout.setVgap(0);
			jPanel3.setVisible(true);
			jPanel3.setPreferredSize(new java.awt.Dimension(267, 125));
			jPanel3.setBounds(new java.awt.Rectangle(0, 0, 0, 0));
			jTabbedPane1.add(jPanel3);
			jTabbedPane1.setTitleAt(3, "testTab");
			FlowLayout jPanel4Layout = new FlowLayout();
			jPanel4.setLayout(jPanel4Layout);
			jPanel4Layout.setAlignment(1);
			jPanel4Layout.setHgap(5);
			jPanel4Layout.setVgap(5);
			jPanel4.setVisible(true);
			jPanel3.add(jPanel4, BorderLayout.NORTH);
			jButton5.setText("jButton5");
			jButton5.setVisible(true);
			jPanel4.add(jButton5);
			jButton5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					jButton5ActionPerformed(evt);
				}
			});
			jButton7.setText("jButton7");
			jButton7.setVisible(true);
			jPanel4.add(jButton7);
			jButton7.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					jButton7ActionPerformed(evt);
				}
			});
			CardLayout jPanel5Layout = new CardLayout();
			jPanel5.setLayout(jPanel5Layout);
			jPanel5Layout.setHgap(0);
			jPanel5Layout.setVgap(0);
			jPanel5.setVisible(true);
			jPanel3.add(jPanel5, BorderLayout.CENTER);
			jButton6.setText("jButton6");
			jButton6.setVisible(true);
			jPanel5.add(jButton6, "jButton6");
			jRadioButton1.setText("jRadioButton1");
			jRadioButton1.setVisible(true);
			jPanel5.add(jRadioButton1, "jRadioButton1");
			jMenuBar1 = new JMenuBar();
			jMenu1 = new JMenu();
			jMenu2 = new JMenu();
			jMenuItem1 = new JMenuItem();
			jSeparator1 = new JSeparator();
			jMenu3 = new JMenu();
			jMenuItem2 = new JMenuItem();
			setJMenuBar(jMenuBar1);
			jMenu1.setText("jMenu1");
			jMenu1.setVisible(true);
			jMenuBar1.add(jMenu1);
			jMenu2.setText("jMenu2");
			jMenu2.setVisible(true);
			jMenu1.add(jMenu2);
			jMenuItem1.setText("jMenuItem1");
			jMenuItem1.setIcon(new ImageIcon("icons/form.gif"));
			jMenuItem1.setVisible(true);
			jMenu2.add(jMenuItem1);
			jSeparator1.setLayout(null);
			jSeparator1.setVisible(true);
			jMenu2.add(jSeparator1);
			jMenu3.setText("jMenu3");
			jMenu3.setVisible(true);
			jMenu2.add(jMenu3);
			jMenuItem2.setText("jMenuItem2");
			jMenuItem2.setIcon(new ImageIcon("icons/sample.gif"));
			jMenuItem2.setVisible(true);
			jMenu3.add(jMenuItem2);
			postInitGUI();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/** Auto-generated main method */
	public static void main(String[] args) {
		showGUI();
	}

	/**
	* Auto-generated code - any changes you make will disappear!!!
	* This static method creates a new instance of this class and shows
	* it inside a new JFrame, (unless it is already a JFrame).
	*/
	public static void showGUI() {
		try {
			JFrame frame = new JFrame();
			TestJApplet2 inst = new TestJApplet2();
			frame.setContentPane(inst);
			frame.pack();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	* Add your pre-init code in here
	*/
	public void preInitGUI() {}
	/**
	* Add your post-init code in here
	*/
	public void postInitGUI() {}
}
