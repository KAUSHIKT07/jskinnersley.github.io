package exampleForms;

import org.eclipse.swt.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
public class FormLayoutDemo extends org.eclipse.swt.widgets.Composite {
	Button button8;
	Button button7;
	Button button6;
	CCombo cCombo2;
	Composite composite2;
	public FormLayoutDemo(Composite parent, int style) {
		super(parent, style);
		initGUI();
	}
	/**
	* Auto-generated code - any changes you make will disappear!!!
	*/
	public void initGUI() {
		try {
			composite2 = new Composite(this, 0);
			cCombo2 = new CCombo(composite2, 8390656);
			button6 = new Button(composite2, 0);
			button7 = new Button(composite2, 0);
			button8 = new Button(composite2, 0);
			this.setSize(new org.eclipse.swt.graphics.Point(210, 106));
			this.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 210, 106));
			composite2.setSize(new org.eclipse.swt.graphics.Point(113, 95));
			composite2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(122, 16, 113, 95));
			cCombo2.setText("ccombo2");
			cCombo2.setSize(new org.eclipse.swt.graphics.Point(174, 44));
			cCombo2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(90, 5, 105, 29));
			FormData cCombo2LData = new FormData();
			cCombo2LData.height = 44;
			cCombo2LData.width = 174;
			cCombo2LData.left = new FormAttachment(button6, 10);
			cCombo2LData.right = new FormAttachment(100, 100, 0);
			cCombo2LData.top = new FormAttachment(0, 100, 0);
			cCombo2LData.bottom = new FormAttachment(button7, -20);
			cCombo2.setLayoutData(cCombo2LData);
			cCombo2.setLayout(null);
			cCombo2.layout();
			button6.setText("button6");
			button6.setSize(new org.eclipse.swt.graphics.Point(90, 33));
			button6.setBounds(
				new org.eclipse.swt.graphics.Rectangle(115, 5, 90, 33));
			FormData button6LData = new FormData();
			button6LData.height = 33;
			button6LData.width = 90;
			button6LData.left = new FormAttachment(0, 100, 0);
			button6LData.right = new FormAttachment(45, 100, 0);
			button6LData.top = new FormAttachment(0, 100, 0);
			button6LData.bottom = new FormAttachment(33, 100, 0);
			button6.setLayoutData(button6LData);
			button7.setText("button7");
			button7.setSize(new org.eclipse.swt.graphics.Point(90, 44));
			button7.setBounds(
				new org.eclipse.swt.graphics.Rectangle(5, 34, 125, 20));
			FormData button7LData = new FormData();
			button7LData.height = 44;
			button7LData.width = 90;
			button7LData.left = new FormAttachment(0, 100, 0);
			button7LData.right = new FormAttachment(cCombo2, 40);
			button7LData.top = new FormAttachment(button6, 10);
			button7LData.bottom = new FormAttachment(button8, -10);
			button7.setLayoutData(button7LData);
			button8.setText("button8");
			button8.setSize(new org.eclipse.swt.graphics.Point(200, 46));
			button8.setBounds(
				new org.eclipse.swt.graphics.Rectangle(90, 74, 105, 21));
			FormData button8LData = new FormData();
			button8LData.height = 46;
			button8LData.width = 200;
			button8LData.left = new FormAttachment(button6, 0);
			button8LData.right = new FormAttachment(100, 100, 0);
			button8LData.top = new FormAttachment(77, 100, 0);
			button8LData.bottom = new FormAttachment(100, 100, 0);
			button8.setLayoutData(button8LData);
			FormLayout composite2Layout = new FormLayout();
			composite2.setLayout(composite2Layout);
			composite2Layout.marginWidth = 5;
			composite2Layout.marginHeight = 5;
			composite2.layout();
			FillLayout thisLayout = new FillLayout(256);
			this.setLayout(thisLayout);
			thisLayout.type = 256;
			this.layout();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/** Auto-generated main method */
	public static void main(String[] args) {
		showGUI();
	}

	/**
	* Auto-generated code - any changes you make will disappear!!!
	* This static method creates a new instance of this class and shows
	* it inside a Shell.
	*/
	public static void showGUI() {
		try {
			Display display = new Display();
			Shell shell = new Shell(display);
			FormLayoutDemo inst = new FormLayoutDemo(shell, SWT.NULL);
			shell.setLayout(new org.eclipse.swt.layout.FillLayout());
			Point size = inst.getSize();
			Rectangle shellBounds = shell.computeTrim(0, 0, size.x, size.y);
			if (shell.getMenuBar() != null)
				shellBounds.height -= 22;
			shell.setSize(shellBounds.width, shellBounds.height);
			shell.open();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
