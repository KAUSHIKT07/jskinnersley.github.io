package exampleForms;

import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.border.*;
public class TestJInternalFrame extends javax.swing.JInternalFrame {
	JButton jButton1;
	JPanel jPanel1;
	public TestJInternalFrame() {
		initGUI();
	}
	/**
	* Auto-generated code - any changes you make will disappear!!!
	*/
	public void initGUI() {
		try {
			jPanel1 = new JPanel();
			jButton1 = new JButton();
			this.getContentPane().setLayout(null);
			this.setResizable(true);
			this.setTitle("test");
			this.setClosable(true);
			this.setIconifiable(true);
			this.setMaximizable(true);
			this.setFrameIcon(
				new ImageIcon(
					getClass().getClassLoader().getResource("icons/form.gif")));
			this.setVisible(true);
			this.setPreferredSize(new java.awt.Dimension(272, 169));
			this.setOpaque(true);
			this.setBounds(new java.awt.Rectangle(0, 0, 272, 169));
			jPanel1.setLayout(null);
			jPanel1.setVisible(true);
			jPanel1.setFont(new java.awt.Font("Verdana", 0, 8));
			jPanel1.setBackground(new java.awt.Color(128, 128, 128));
			jPanel1.setPreferredSize(new java.awt.Dimension(137, 87));
			jPanel1.setBorder(
				new CompoundBorder(
					new TitledBorder(
						null,
						"hello",
						3,
						2,
						new java.awt.Font("Verdana", 0, 9),
						new java.awt.Color(255, 255, 255)),
					new BevelBorder(1, null, null, null, null)));
			jPanel1.setBounds(new java.awt.Rectangle(49, 16, 137, 87));
			this.getContentPane().add(jPanel1);
			jButton1.setText("jButton1");
			jButton1.setVisible(true);
			jButton1.setPreferredSize(new java.awt.Dimension(83, 26));
			jButton1.setBounds(new java.awt.Rectangle(23, 32, 83, 26));
			jPanel1.add(jButton1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/** Auto-generated main method */
	public static void main(String[] args) {
		showGUI();
	}

	/**
	* Auto-generated code - any changes you make will disappear!!!
	* This static method creates a new instance of this class and shows
	* it inside a new JFrame, (unless it is already a JFrame).
	*/
	public static void showGUI() {
		try {
			JFrame frame = new JFrame();
			TestJInternalFrame inst = new TestJInternalFrame();
			JDesktopPane jdp = new JDesktopPane();
			jdp.add(inst);
			jdp.setPreferredSize(inst.getPreferredSize());
			frame.setContentPane(jdp);
			frame.pack();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
