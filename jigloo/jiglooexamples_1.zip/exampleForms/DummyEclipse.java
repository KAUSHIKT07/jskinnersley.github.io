package exampleForms;

import org.eclipse.swt.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.custom.ViewForm;
public class DummyEclipse extends org.eclipse.swt.widgets.Composite {
	MenuItem aboutMenuItem;
	MenuItem separator3;
	MenuItem welcomeMenuItem;
	Menu menu16;
	MenuItem helpMenuItem;
	MenuItem separator2;
	MenuItem exitMenuItem;
	MenuItem saveMenuItem;
	MenuItem closeMenuItem;
	MenuItem separator1;
	MenuItem newProjectMenuItem;
	Menu menu2;
	CTabItem cTabItem10;
	CTabFolder cTabFolder6;
	Text text2;
	SashForm sashForm3;
	MenuItem newMenuItem;
	Menu menu3;
	Button button6;
	Button button5;
	ViewForm viewForm1;
	Tree tree7;
	Composite composite22;
	Composite composite21;
	TreeItem treeItem15;
	TreeItem treeItem14;
	TreeItem treeItem13;
	TableColumn tableColumn6;
	TableColumn tableColumn5;
	Table table2;
	CLabel cLabel9;
	Composite composite20;
	Composite composite19;
	CTabItem cTabItem7;
	CLabel cLabel7;
	Composite composite18;
	TreeItem treeItem9;
	TreeItem treeItem8;
	TreeItem treeItem7;
	Tree tree3;
	TableColumn tableColumn4;
	TableColumn tableColumn3;
	Table table1;
	CTabItem cTabItem8;
	TableColumn tableColumn2;
	TableColumn tableColumn1;
	TreeItem treeItem12;
	TreeItem treeItem11;
	TreeItem treeItem10;
	Table tree6;
	CLabel cLabel8;
	Composite composite24;
	Composite composite23;
	CTabItem cTabItem9;
	CTabFolder cTabFolder5;
	Text text1;
	ScrolledComposite scrolledComposite1;
	CTabItem cTabItem3;
	CTabFolder cTabFolder4;
	TreeItem treeItem6;
	TreeItem treeItem5;
	TreeItem treeItem4;
	Tree tree2;
	CLabel cLabel6;
	Composite composite17;
	Composite composite16;
	CTabItem cTabItem2;
	TreeItem treeItem3;
	TreeItem treeItem2;
	TreeItem treeItem1;
	Tree tree1;
	Composite composite7;
	CLabel cLabel3;
	Composite composite6;
	Composite composite5;
	Composite composite4;
	CTabItem cTabItem1;
	CTabFolder cTabFolder1;
	SashForm sashForm2;
	MenuItem fileMenuItem;
	Menu menu1;
	Button button4;
	Composite composite3;
	CTabItem cTabItem6;
	CTabFolder cTabFolder3;
	TreeItem treeItem21;
	TreeItem treeItem20;
	TreeItem treeItem19;
	Tree tree5;
	CLabel cLabel5;
	Composite composite15;
	Composite composite14;
	CTabItem cTabItem5;
	TreeItem treeItem18;
	TreeItem treeItem17;
	TreeItem treeItem16;
	Tree tree4;
	Composite composite12;
	CLabel cLabel4;
	Composite composite11;
	Composite composite10;
	Composite composite9;
	CTabItem cTabItem4;
	CTabFolder cTabFolder2;
	Label label2;
	Label label4;
	Label label3;
	Composite composite13;
	Composite composite8;
	CoolItem coolItem2;
	Button cLabel2;
	Button cLabel1;
	Composite composite2;
	CoolItem coolItem3;
	CoolItem coolItem1;
	CoolBar coolBar1;
	Composite composite1;
	Label label1;
	Button button3;
	Button button2;
	SashForm sashForm1;
	Button button1;
	public DummyEclipse(Composite parent, int style) {
		super(parent, style);
		initGUI();
	}
	/**
	* Auto-generated code - any changes you make will disappear!!!
	*/
	public void initGUI() {
		try {
			label1 = new Label(this, 258);
			composite1 = new Composite(this, 0);
			coolBar1 = new CoolBar(composite1, 0);
			coolItem3 = new CoolItem(coolBar1, 4);
			composite2 = new Composite(coolBar1, 0);
			cLabel1 = new Button(composite2, 8388616);
			cLabel2 = new Button(composite2, 8388610);
			button1 = new Button(composite2, 25165832);
			coolItem2 = new CoolItem(coolBar1, 4);
			composite3 = new Composite(coolBar1, 0);
			button4 = new Button(composite3, 8388616);
			button5 = new Button(composite3, 8388610);
			button6 = new Button(composite3, 25165832);
			coolItem1 = new CoolItem(coolBar1, 4);
			composite8 = new Composite(this, 0);
			composite13 = new Composite(composite8, 0);
			button2 = new Button(composite13, 25165832);
			label3 = new Label(composite13, 258);
			button3 = new Button(composite13, 25165832);
			label4 = new Label(composite13, 258);
			label2 = new Label(composite8, 2);
			composite6 = new Composite(composite8, 0);
			sashForm2 = new SashForm(composite6, 0);
			sashForm3 = new SashForm(sashForm2, 0);
			cTabFolder2 = new CTabFolder(sashForm3, 3080);
			cTabItem4 = new CTabItem(cTabFolder2, 0);
			composite7 = new Composite(cTabFolder2, 0);
			composite9 = new Composite(composite7, 0);
			cLabel4 = new CLabel(composite9, 0);
			tree3 = new Tree(composite7, 0);
			treeItem7 = new TreeItem(tree3, 0);
			treeItem8 = new TreeItem(treeItem7, 0);
			treeItem9 = new TreeItem(treeItem7, 0);
			cTabItem5 = new CTabItem(cTabFolder2, 0);
			composite10 = new Composite(cTabFolder2, 0);
			composite11 = new Composite(composite10, 0);
			cLabel5 = new CLabel(composite11, 0);
			tree4 = new Tree(composite10, 0);
			treeItem10 = new TreeItem(tree4, 0);
			treeItem11 = new TreeItem(treeItem10, 0);
			treeItem12 = new TreeItem(treeItem10, 0);
			cTabFolder3 = new CTabFolder(sashForm3, 2056);
			cTabItem6 = new CTabItem(cTabFolder3, 0);
			text2 = new Text(cTabFolder3, 770);
			cTabItem7 = new CTabItem(cTabFolder3, 0);
			cTabFolder6 = new CTabFolder(sashForm2, 3080);
			cTabItem10 = new CTabItem(cTabFolder6, 0);
			composite12 = new Composite(cTabFolder6, 0);
			composite14 = new Composite(composite12, 0);
			cLabel7 = new CLabel(composite14, 0);
			table1 = new Table(composite12, 0);
			tableColumn3 = new TableColumn(table1, 0);
			tableColumn4 = new TableColumn(table1, 0);
			this.setSize(new org.eclipse.swt.graphics.Point(488, 348));
			this.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 488, 348));
			label1.setText("label1");
			label1.setVisible(true);
			GridData label1LData = new GridData();
			label1LData.verticalAlignment = 2;
			label1LData.horizontalAlignment = 4;
			label1LData.widthHint = -1;
			label1LData.heightHint = -1;
			label1LData.horizontalIndent = 0;
			label1LData.horizontalSpan = 1;
			label1LData.verticalSpan = 1;
			label1LData.grabExcessHorizontalSpace = false;
			label1LData.grabExcessVerticalSpace = false;
			label1.setLayoutData(label1LData);
			composite1.setSize(new org.eclipse.swt.graphics.Point(486, 30));
			composite1.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 2, 486, 30));
			composite1.setVisible(true);
			GridData composite1LData = new GridData();
			composite1LData.verticalAlignment = 2;
			composite1LData.horizontalAlignment = 4;
			composite1LData.widthHint = 486;
			composite1LData.heightHint = 30;
			composite1LData.horizontalIndent = 0;
			composite1LData.horizontalSpan = 1;
			composite1LData.verticalSpan = 1;
			composite1LData.grabExcessHorizontalSpace = true;
			composite1LData.grabExcessVerticalSpace = false;
			composite1.setLayoutData(composite1LData);
			coolBar1.setSize(new org.eclipse.swt.graphics.Point(387, 30));
			coolBar1.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 486, 30));
			coolBar1.setVisible(true);
			coolItem3.setSize(new org.eclipse.swt.graphics.Point(106, 28));
			coolItem3.setMinimumSize(new org.eclipse.swt.graphics.Point(80, 0));
			coolItem3.setPreferredSize(
				new org.eclipse.swt.graphics.Point(106, 28));
			coolItem3.setText("coolItem3");
			composite2.setSize(new org.eclipse.swt.graphics.Point(96, 28));
			composite2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(9, 0, 96, 28));
			composite2.setVisible(true);
			coolItem3.setControl(composite2);
			final org.eclipse.swt.graphics.Image cLabel1image =
				new org.eclipse.swt.graphics.Image(
					getDisplay(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/tickBox.gif"));
			cLabel1image.setBackground(cLabel1.getBackground());
			cLabel1.setImage(cLabel1image);
			cLabel1.setSize(new org.eclipse.swt.graphics.Point(29, 24));
			cLabel1.setBounds(
				new org.eclipse.swt.graphics.Rectangle(1, 1, 29, 24));
			cLabel1.setVisible(true);
			RowData cLabel1LData = new RowData(29, 24);
			cLabel1.setLayoutData(cLabel1LData);
			final org.eclipse.swt.graphics.Image cLabel2image =
				new org.eclipse.swt.graphics.Image(
					getDisplay(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/form.gif"));
			cLabel2image.setBackground(cLabel2.getBackground());
			cLabel2.setImage(cLabel2image);
			cLabel2.setSize(new org.eclipse.swt.graphics.Point(28, 24));
			cLabel2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(32, 1, 28, 24));
			cLabel2.setVisible(true);
			RowData cLabel2LData = new RowData(28, 24);
			cLabel2.setLayoutData(cLabel2LData);
			button1.setText("Test");
			button1.setSize(new org.eclipse.swt.graphics.Point(29, 24));
			button1.setBounds(
				new org.eclipse.swt.graphics.Rectangle(55, 1, 29, 24));
			button1.setVisible(true);
			RowData button1LData = new RowData(29, 24);
			button1.setLayoutData(button1LData);
			RowLayout composite2Layout = new RowLayout(256);
			composite2.setLayout(composite2Layout);
			composite2Layout.type = 256;
			composite2Layout.wrap = false;
			composite2Layout.pack = true;
			composite2Layout.justify = false;
			composite2Layout.spacing = 2;
			composite2Layout.marginLeft = 1;
			composite2Layout.marginTop = 1;
			composite2Layout.marginRight = 1;
			composite2Layout.marginBottom = 1;
			composite2.layout();
			coolItem2.setSize(new org.eclipse.swt.graphics.Point(207, 28));
			coolItem2.setPreferredSize(
				new org.eclipse.swt.graphics.Point(207, 28));
			coolItem2.setText("coolItem2");
			composite3.setSize(new org.eclipse.swt.graphics.Point(147, 28));
			composite3.setBounds(
				new org.eclipse.swt.graphics.Rectangle(-240, 0, 147, 28));
			composite3.setVisible(true);
			coolItem2.setControl(composite3);
			final org.eclipse.swt.graphics.Image button4image =
				new org.eclipse.swt.graphics.Image(
					getDisplay(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/form.gif"));
			button4image.setBackground(button4.getBackground());
			button4.setImage(button4image);
			button4.setSize(new org.eclipse.swt.graphics.Point(29, 24));
			button4.setBounds(
				new org.eclipse.swt.graphics.Rectangle(1, 1, 29, 24));
			button4.setVisible(true);
			RowData button4LData = new RowData(29, 24);
			button4.setLayoutData(button4LData);
			final org.eclipse.swt.graphics.Image button5image =
				new org.eclipse.swt.graphics.Image(
					getDisplay(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/sample.gif"));
			button5image.setBackground(button5.getBackground());
			button5.setImage(button5image);
			button5.setSize(new org.eclipse.swt.graphics.Point(28, 24));
			button5.setBounds(
				new org.eclipse.swt.graphics.Rectangle(32, 1, 28, 24));
			button5.setVisible(true);
			RowData button5LData = new RowData(28, 24);
			button5.setLayoutData(button5LData);
			button6.setText("Run");
			button6.setSize(new org.eclipse.swt.graphics.Point(43, 24));
			button6.setBounds(
				new org.eclipse.swt.graphics.Rectangle(62, 1, 43, 24));
			button6.setVisible(true);
			RowData button6LData = new RowData(43, 24);
			button6.setLayoutData(button6LData);
			RowLayout composite3Layout = new RowLayout(256);
			composite3.setLayout(composite3Layout);
			composite3Layout.type = 256;
			composite3Layout.wrap = false;
			composite3Layout.pack = true;
			composite3Layout.justify = false;
			composite3Layout.spacing = 2;
			composite3Layout.marginLeft = 1;
			composite3Layout.marginTop = 1;
			composite3Layout.marginRight = 1;
			composite3Layout.marginBottom = 1;
			composite3.layout();
			coolItem1.setSize(new org.eclipse.swt.graphics.Point(238, 28));
			coolItem1.setPreferredSize(
				new org.eclipse.swt.graphics.Point(238, 28));
			coolItem1.setText("coolItem1");
			coolBar1.setLayout(null);
			coolBar1.layout();
			FillLayout composite1Layout = new FillLayout(256);
			composite1.setLayout(composite1Layout);
			composite1Layout.type = 256;
			composite1.layout();
			composite8.setSize(new org.eclipse.swt.graphics.Point(-310, -183));
			composite8.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 33, 475, 289));
			composite8.setVisible(true);
			GridData composite8LData = new GridData();
			composite8LData.verticalAlignment = 4;
			composite8LData.horizontalAlignment = 4;
			composite8LData.widthHint = -310;
			composite8LData.heightHint = -183;
			composite8LData.horizontalIndent = 0;
			composite8LData.horizontalSpan = 1;
			composite8LData.verticalSpan = 1;
			composite8LData.grabExcessHorizontalSpace = false;
			composite8LData.grabExcessVerticalSpace = true;
			composite8.setLayoutData(composite8LData);
			composite13.setSize(new org.eclipse.swt.graphics.Point(30, -66));
			composite13.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 30, 245));
			composite13.setVisible(true);
			GridData composite13LData = new GridData();
			composite13LData.verticalAlignment = 4;
			composite13LData.horizontalAlignment = 1;
			composite13LData.widthHint = 30;
			composite13LData.heightHint = -66;
			composite13LData.horizontalIndent = 0;
			composite13LData.horizontalSpan = 1;
			composite13LData.verticalSpan = 1;
			composite13LData.grabExcessHorizontalSpace = false;
			composite13LData.grabExcessVerticalSpace = true;
			composite13.setLayoutData(composite13LData);
			final org.eclipse.swt.graphics.Image button2image =
				new org.eclipse.swt.graphics.Image(
					getDisplay(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/form.gif"));
			button2image.setBackground(button2.getBackground());
			button2.setImage(button2image);
			button2.setSize(new org.eclipse.swt.graphics.Point(24, 25));
			button2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 2, 30, 25));
			button2.setVisible(true);
			GridData button2LData = new GridData();
			button2LData.verticalAlignment = 2;
			button2LData.horizontalAlignment = 4;
			button2LData.widthHint = 24;
			button2LData.heightHint = 25;
			button2LData.horizontalIndent = 0;
			button2LData.horizontalSpan = 1;
			button2LData.verticalSpan = 1;
			button2LData.grabExcessHorizontalSpace = false;
			button2LData.grabExcessVerticalSpace = false;
			button2.setLayoutData(button2LData);
			label3.setText("label3");
			label3.setSize(new org.eclipse.swt.graphics.Point(27, 2));
			label3.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 29, 30, 2));
			label3.setVisible(true);
			GridData label3LData = new GridData();
			label3LData.verticalAlignment = 2;
			label3LData.horizontalAlignment = 4;
			label3LData.widthHint = 27;
			label3LData.heightHint = 2;
			label3LData.horizontalIndent = 0;
			label3LData.horizontalSpan = 1;
			label3LData.verticalSpan = 1;
			label3LData.grabExcessHorizontalSpace = false;
			label3LData.grabExcessVerticalSpace = false;
			label3.setLayoutData(label3LData);
			final org.eclipse.swt.graphics.Image button3image =
				new org.eclipse.swt.graphics.Image(
					getDisplay(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/sample.gif"));
			button3image.setBackground(button3.getBackground());
			button3.setImage(button3image);
			button3.setSize(new org.eclipse.swt.graphics.Point(22, 25));
			button3.setBounds(
				new org.eclipse.swt.graphics.Rectangle(2, 31, 22, 25));
			button3.setVisible(true);
			GridData button3LData = new GridData();
			button3LData.verticalAlignment = 2;
			button3LData.horizontalAlignment = 4;
			button3LData.widthHint = 22;
			button3LData.heightHint = 25;
			button3LData.horizontalIndent = 0;
			button3LData.horizontalSpan = 1;
			button3LData.verticalSpan = 1;
			button3LData.grabExcessHorizontalSpace = false;
			button3LData.grabExcessVerticalSpace = false;
			button3.setLayoutData(button3LData);
			label4.setText("label3");
			label4.setSize(new org.eclipse.swt.graphics.Point(27, 2));
			label4.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 60, 30, 2));
			label4.setVisible(true);
			GridData label4LData = new GridData();
			label4LData.verticalAlignment = 2;
			label4LData.horizontalAlignment = 4;
			label4LData.widthHint = 27;
			label4LData.heightHint = 2;
			label4LData.horizontalIndent = 0;
			label4LData.horizontalSpan = 1;
			label4LData.verticalSpan = 1;
			label4LData.grabExcessHorizontalSpace = false;
			label4LData.grabExcessVerticalSpace = false;
			label4.setLayoutData(label4LData);
			GridLayout composite13Layout = new GridLayout(1, true);
			composite13.setLayout(composite13Layout);
			composite13Layout.marginWidth = 0;
			composite13Layout.marginHeight = 2;
			composite13Layout.numColumns = 1;
			composite13Layout.makeColumnsEqualWidth = true;
			composite13Layout.horizontalSpacing = 0;
			composite13Layout.verticalSpacing = 2;
			composite13.layout();
			label2.setText("label2");
			label2.setSize(new org.eclipse.swt.graphics.Point(2, -1));
			label2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(32, 0, 2, 296));
			label2.setVisible(true);
			GridData label2LData = new GridData();
			label2LData.verticalAlignment = 4;
			label2LData.horizontalAlignment = 1;
			label2LData.widthHint = 2;
			label2LData.heightHint = -1;
			label2LData.horizontalIndent = 0;
			label2LData.horizontalSpan = 1;
			label2LData.verticalSpan = 1;
			label2LData.grabExcessHorizontalSpace = false;
			label2LData.grabExcessVerticalSpace = true;
			label2.setLayoutData(label2LData);
			composite6.setVisible(true);
			GridData composite6LData = new GridData();
			composite6LData.verticalAlignment = 4;
			composite6LData.horizontalAlignment = 4;
			composite6LData.widthHint = -1;
			composite6LData.heightHint = -1;
			composite6LData.horizontalIndent = 0;
			composite6LData.horizontalSpan = 1;
			composite6LData.verticalSpan = 1;
			composite6LData.grabExcessHorizontalSpace = true;
			composite6LData.grabExcessVerticalSpace = true;
			composite6.setLayoutData(composite6LData);
			sashForm2.setOrientation(512);
			sashForm2.setSize(new org.eclipse.swt.graphics.Point(270, 175));
			sashForm2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(37, 2, 442, 284));
			sashForm2.setVisible(true);
			GridData sashForm2LData = new GridData();
			sashForm2LData.verticalAlignment = 4;
			sashForm2LData.horizontalAlignment = 4;
			sashForm2LData.widthHint = 270;
			sashForm2LData.heightHint = 175;
			sashForm2LData.horizontalIndent = 0;
			sashForm2LData.horizontalSpan = 1;
			sashForm2LData.verticalSpan = 1;
			sashForm2LData.grabExcessHorizontalSpace = true;
			sashForm2LData.grabExcessVerticalSpace = true;
			sashForm2.setLayoutData(sashForm2LData);
			sashForm3.setSize(new org.eclipse.swt.graphics.Point(442, 284));
			sashForm3.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 442, 284));
			sashForm3.setVisible(true);
			cTabFolder2.setSize(new org.eclipse.swt.graphics.Point(214, 116));
			cTabFolder2.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 218, 140));
			cTabFolder2.setVisible(true);
			cTabItem4.setText("Package Explorer");
			composite7.setVisible(true);
			cTabItem4.setControl(composite7);
			composite9.setSize(new org.eclipse.swt.graphics.Point(163, 24));
			composite9.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 163, 24));
			composite9.setVisible(true);
			GridData composite9LData = new GridData();
			composite9LData.verticalAlignment = 2;
			composite9LData.horizontalAlignment = 4;
			composite9LData.widthHint = 163;
			composite9LData.heightHint = 24;
			composite9LData.horizontalIndent = 0;
			composite9LData.horizontalSpan = 1;
			composite9LData.verticalSpan = 1;
			composite9LData.grabExcessHorizontalSpace = true;
			composite9LData.grabExcessVerticalSpace = false;
			composite9.setLayoutData(composite9LData);
			final org.eclipse.swt.graphics.Image cLabel4image =
				new org.eclipse.swt.graphics.Image(
					getDisplay(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/form.gif"));
			cLabel4image.setBackground(cLabel4.getBackground());
			cLabel4.setImage(cLabel4image);
			cLabel4.setText("Package Explorer");
			cLabel4.setSize(new org.eclipse.swt.graphics.Point(100, 20));
			cLabel4.setBounds(
				new org.eclipse.swt.graphics.Rectangle(4, 2, 100, 20));
			cLabel4.setVisible(true);
			RowData cLabel4LData = new RowData(100, 20);
			cLabel4.setLayoutData(cLabel4LData);
			cLabel4.setLayout(null);
			cLabel4.layout();
			RowLayout composite9Layout = new RowLayout(256);
			composite9.setLayout(composite9Layout);
			composite9Layout.type = 256;
			composite9Layout.wrap = true;
			composite9Layout.pack = true;
			composite9Layout.justify = false;
			composite9Layout.spacing = 3;
			composite9Layout.marginLeft = 3;
			composite9Layout.marginTop = 3;
			composite9Layout.marginRight = 3;
			composite9Layout.marginBottom = 3;
			composite9.layout();
			tree3.setSize(new org.eclipse.swt.graphics.Point(197, 74));
			tree3.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 24, 213, 90));
			tree3.setVisible(true);
			GridData tree3LData = new GridData();
			tree3LData.verticalAlignment = 4;
			tree3LData.horizontalAlignment = 4;
			tree3LData.widthHint = 197;
			tree3LData.heightHint = 74;
			tree3LData.horizontalIndent = 0;
			tree3LData.horizontalSpan = 1;
			tree3LData.verticalSpan = 1;
			tree3LData.grabExcessHorizontalSpace = false;
			tree3LData.grabExcessVerticalSpace = true;
			tree3.setLayoutData(tree3LData);
			treeItem7.setText("treeItem1");
			treeItem7.setExpanded(true);
			treeItem8.setText("treeItem2");
			treeItem9.setText("treeItem3");
			tree3.setLayout(null);
			tree3.layout();
			GridLayout composite7Layout = new GridLayout(1, true);
			composite7.setLayout(composite7Layout);
			composite7Layout.marginWidth = 0;
			composite7Layout.marginHeight = 0;
			composite7Layout.numColumns = 1;
			composite7Layout.makeColumnsEqualWidth = true;
			composite7Layout.horizontalSpacing = 0;
			composite7Layout.verticalSpacing = 0;
			composite7.layout();
			cTabItem5.setText("Hierarchy");
			composite10.setVisible(true);
			cTabItem5.setControl(composite10);
			composite11.setSize(new org.eclipse.swt.graphics.Point(213, 24));
			composite11.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 213, 24));
			composite11.setVisible(true);
			GridData composite11LData = new GridData();
			composite11LData.verticalAlignment = 2;
			composite11LData.horizontalAlignment = 4;
			composite11LData.widthHint = 213;
			composite11LData.heightHint = 24;
			composite11LData.horizontalIndent = 0;
			composite11LData.horizontalSpan = 1;
			composite11LData.verticalSpan = 1;
			composite11LData.grabExcessHorizontalSpace = true;
			composite11LData.grabExcessVerticalSpace = false;
			composite11.setLayoutData(composite11LData);
			final org.eclipse.swt.graphics.Image cLabel5image =
				new org.eclipse.swt.graphics.Image(
					getDisplay(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/sample.gif"));
			cLabel5image.setBackground(cLabel5.getBackground());
			cLabel5.setImage(cLabel5image);
			cLabel5.setText("Hierarchy");
			cLabel5.setSize(new org.eclipse.swt.graphics.Point(85, 17));
			cLabel5.setBounds(
				new org.eclipse.swt.graphics.Rectangle(3, 3, 85, 17));
			cLabel5.setVisible(true);
			cLabel5.setLayout(null);
			cLabel5.layout();
			composite11.setLayout(null);
			composite11.layout();
			tree4.setSize(new org.eclipse.swt.graphics.Point(-122, -34));
			tree4.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 24, 209, 236));
			tree4.setVisible(true);
			GridData tree4LData = new GridData();
			tree4LData.verticalAlignment = 4;
			tree4LData.horizontalAlignment = 4;
			tree4LData.widthHint = -122;
			tree4LData.heightHint = -34;
			tree4LData.horizontalIndent = 0;
			tree4LData.horizontalSpan = 1;
			tree4LData.verticalSpan = 1;
			tree4LData.grabExcessHorizontalSpace = true;
			tree4LData.grabExcessVerticalSpace = true;
			tree4.setLayoutData(tree4LData);
			treeItem10.setText("treeItem1");
			treeItem10.setExpanded(true);
			treeItem11.setText("treeItem2");
			treeItem12.setText("treeItem3");
			tree4.setLayout(null);
			tree4.layout();
			GridLayout composite10Layout = new GridLayout(1, true);
			composite10.setLayout(composite10Layout);
			composite10Layout.marginWidth = 0;
			composite10Layout.marginHeight = 0;
			composite10Layout.numColumns = 1;
			composite10Layout.makeColumnsEqualWidth = true;
			composite10Layout.horizontalSpacing = 0;
			composite10Layout.verticalSpacing = 0;
			composite10.layout();
			cTabFolder2.setLayout(null);
			cTabFolder2.layout();
			cTabFolder2.setSelection(0);
			cTabFolder3.setSize(new org.eclipse.swt.graphics.Point(222, 114));
			cTabFolder3.setBounds(
				new org.eclipse.swt.graphics.Rectangle(224, 0, 226, 141));
			cTabFolder3.setVisible(true);
			final org.eclipse.swt.graphics.Image cTabItem6image =
				new org.eclipse.swt.graphics.Image(
					getDisplay(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/form.gif"));
			cTabItem6.setImage(cTabItem6image);
			cTabItem6.setText("FakeJava.java");
			text2.setText(
				"package fake;\n\npublic class FakeJava {\n\n\tpublic FakeJava() {\n\t}\n\n}");
			text2.setVisible(true);
			cTabItem6.setControl(text2);
			cTabItem7.setText("OtherObject");
			cTabFolder3.setLayout(null);
			cTabFolder3.layout();
			cTabFolder3.setSelection(0);
			sashForm3.setLayout(null);
			sashForm3.layout();
			cTabFolder6.setSize(new org.eclipse.swt.graphics.Point(213, 114));
			cTabFolder6.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 217, 138));
			cTabFolder6.setVisible(true);
			cTabItem10.setText("Properties");
			composite12.setVisible(true);
			cTabItem10.setControl(composite12);
			composite14.setSize(new org.eclipse.swt.graphics.Point(213, 24));
			composite14.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 0, 438, 24));
			composite14.setVisible(true);
			final Color composite14background =
				new Color(getDisplay(), 16, 1, 194);
			composite14.setBackground(composite14background);
			GridData composite14LData = new GridData();
			composite14LData.verticalAlignment = 2;
			composite14LData.horizontalAlignment = 4;
			composite14LData.widthHint = 213;
			composite14LData.heightHint = 24;
			composite14LData.horizontalIndent = 0;
			composite14LData.horizontalSpan = 1;
			composite14LData.verticalSpan = 1;
			composite14LData.grabExcessHorizontalSpace = true;
			composite14LData.grabExcessVerticalSpace = false;
			composite14.setLayoutData(composite14LData);
			final org.eclipse.swt.graphics.Image cLabel7image =
				new org.eclipse.swt.graphics.Image(
					getDisplay(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/sample.gif"));
			cLabel7image.setBackground(cLabel7.getBackground());
			cLabel7.setImage(cLabel7image);
			cLabel7.setText("Properties");
			final Color cLabel7background = new Color(getDisplay(), 16, 1, 194);
			cLabel7.setBackground(cLabel7background);
			cLabel7.setSize(new org.eclipse.swt.graphics.Point(85, 17));
			cLabel7.setBounds(
				new org.eclipse.swt.graphics.Rectangle(3, 3, 85, 17));
			cLabel7.setVisible(true);
			final Color cLabel7foreground =
				new Color(getDisplay(), 255, 255, 255);
			cLabel7.setForeground(cLabel7foreground);
			cLabel7.setLayout(null);
			cLabel7.layout();
			composite14.setLayout(null);
			composite14.layout();
			table1.setHeaderVisible(true);
			table1.setLinesVisible(true);
			table1.setSize(new org.eclipse.swt.graphics.Point(422, 79));
			table1.setBounds(
				new org.eclipse.swt.graphics.Rectangle(0, 24, 438, 95));
			table1.setVisible(true);
			GridData table1LData = new GridData();
			table1LData.verticalAlignment = 4;
			table1LData.horizontalAlignment = 4;
			table1LData.widthHint = 422;
			table1LData.heightHint = 79;
			table1LData.horizontalIndent = 0;
			table1LData.horizontalSpan = 1;
			table1LData.verticalSpan = 1;
			table1LData.grabExcessHorizontalSpace = false;
			table1LData.grabExcessVerticalSpace = true;
			table1.setLayoutData(table1LData);
			tableColumn3.setText("Property");
			tableColumn3.setWidth(100);
			tableColumn4.setText("Value");
			tableColumn4.setWidth(100);
			table1.setLayout(null);
			table1.layout();
			GridLayout composite12Layout = new GridLayout(1, true);
			composite12.setLayout(composite12Layout);
			composite12Layout.marginWidth = 0;
			composite12Layout.marginHeight = 0;
			composite12Layout.numColumns = 1;
			composite12Layout.makeColumnsEqualWidth = true;
			composite12Layout.horizontalSpacing = 0;
			composite12Layout.verticalSpacing = 0;
			composite12.layout();
			cTabFolder6.setLayout(null);
			cTabFolder6.layout();
			cTabFolder6.setSelection(0);
			sashForm2.setLayout(null);
			sashForm2.layout();
			GridLayout composite6Layout = new GridLayout(1, true);
			composite6.setLayout(composite6Layout);
			composite6Layout.marginWidth = 1;
			composite6Layout.marginHeight = 3;
			composite6Layout.numColumns = 1;
			composite6Layout.makeColumnsEqualWidth = true;
			composite6Layout.horizontalSpacing = 2;
			composite6Layout.verticalSpacing = 2;
			composite6.layout();
			GridLayout composite8Layout = new GridLayout(3, true);
			composite8.setLayout(composite8Layout);
			composite8Layout.marginWidth = 0;
			composite8Layout.marginHeight = 0;
			composite8Layout.numColumns = 3;
			composite8Layout.makeColumnsEqualWidth = false;
			composite8Layout.horizontalSpacing = 2;
			composite8Layout.verticalSpacing = 0;
			composite8.layout();
			GridLayout thisLayout = new GridLayout(1, true);
			this.setLayout(thisLayout);
			thisLayout.marginWidth = 0;
			thisLayout.marginHeight = 0;
			thisLayout.numColumns = 1;
			thisLayout.makeColumnsEqualWidth = true;
			thisLayout.horizontalSpacing = 0;
			thisLayout.verticalSpacing = 0;
			this.layout();
			menu1 = new Menu(getShell(), 2);
			fileMenuItem = new MenuItem(menu1, 64);
			menu3 = new Menu(fileMenuItem);
			newMenuItem = new MenuItem(menu3, 64);
			menu2 = new Menu(newMenuItem);
			newProjectMenuItem = new MenuItem(menu2, 8);
			separator1 = new MenuItem(menu3, 2);
			closeMenuItem = new MenuItem(menu3, 8);
			saveMenuItem = new MenuItem(menu3, 8);
			separator2 = new MenuItem(menu3, 2);
			exitMenuItem = new MenuItem(menu3, 8);
			helpMenuItem = new MenuItem(menu1, 64);
			menu16 = new Menu(helpMenuItem);
			welcomeMenuItem = new MenuItem(menu16, 8);
			separator3 = new MenuItem(menu16, 2);
			aboutMenuItem = new MenuItem(menu16, 8);
			getShell().setMenuBar(menu1);
			menu1.setVisible(true);
			fileMenuItem.setText("&File");
			fileMenuItem.setMenu(menu3);
			menu3.setVisible(true);
			newMenuItem.setText("&New");
			newMenuItem.setMenu(menu2);
			menu2.setVisible(true);
			newProjectMenuItem.setText("Project");
			separator1.setText("menuItem10");
			closeMenuItem.setText("&Close");
			final org.eclipse.swt.graphics.Image saveMenuItemimage =
				new org.eclipse.swt.graphics.Image(
					getDisplay(),
					getClass().getClassLoader().getResourceAsStream(
						"icons/save.gif"));
			saveMenuItem.setImage(saveMenuItemimage);
			saveMenuItem.setText("&Save");
			separator2.setText("separator2");
			exitMenuItem.setText("E&xit");
			helpMenuItem.setText("&Help");
			helpMenuItem.setMenu(menu16);
			menu16.setVisible(true);
			welcomeMenuItem.setText("Welcome");
			separator3.setText("separator3");
			aboutMenuItem.setText("About Eclipse...");
			addDisposeListener(new DisposeListener() {
				public void widgetDisposed(DisposeEvent e) {
					cLabel1image.dispose();
					cLabel2image.dispose();
					button4image.dispose();
					button5image.dispose();
					button2image.dispose();
					button3image.dispose();
					cLabel4image.dispose();
					cLabel5image.dispose();
					cTabItem6image.dispose();
					composite14background.dispose();
					cLabel7image.dispose();
					cLabel7background.dispose();
					cLabel7foreground.dispose();
					saveMenuItemimage.dispose();
				}

			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/** Auto-generated main method */
	public static void main(String[] args) {
		showGUI();
	}

	/**
	* Auto-generated code - any changes you make will disappear!!!
	* This static method creates a new instance of this class and shows
	* it inside a Shell.
	*/
	public static void showGUI() {
		try {
			Display display = new Display();
			Shell shell = new Shell(display);
			DummyEclipse inst = new DummyEclipse(shell, SWT.NULL);
			shell.setLayout(new org.eclipse.swt.layout.FillLayout());
			Point size = inst.getSize();
			Rectangle shellBounds = shell.computeTrim(0, 0, size.x, size.y);
			if (shell.getMenuBar() != null)
				shellBounds.height -= 22;
			shell.setSize(shellBounds.width, shellBounds.height);
			shell.open();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
